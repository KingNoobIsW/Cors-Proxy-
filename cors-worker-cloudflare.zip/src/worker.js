export default {
  async fetch(request) {
    if (request.method === "OPTIONS") {
      return new Response(null, { headers: corsHeaders() });
    }

    const url = new URL(request.url);
    const target = url.searchParams.get("url");

    if (!target) {
      return new Response(
        "Usage: ?url=https://example.com",
        { status: 400, headers: corsHeaders() }
      );
    }

    let targetUrl;
    try {
      targetUrl = new URL(target);
    } catch {
      return new Response("Invalid URL", {
        status: 400,
        headers: corsHeaders()
      });
    }

    const newHeaders = new Headers(request.headers);
    newHeaders.delete("host");
    newHeaders.delete("origin");
    newHeaders.delete("referer");

    const response = await fetch(targetUrl.toString(), {
      method: request.method,
      headers: newHeaders,
      body: request.method !== "GET" && request.method !== "HEAD"
        ? await request.arrayBuffer()
        : null,
      redirect: "follow"
    });

    const responseHeaders = new Headers(response.headers);
    applyCors(responseHeaders);

    return new Response(response.body, {
      status: response.status,
      headers: responseHeaders
    });
  }
};

function corsHeaders() {
  return {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET,HEAD,POST,PUT,PATCH,DELETE,OPTIONS",
    "Access-Control-Allow-Headers": "*",
    "Access-Control-Allow-Credentials": "true"
  };
}

function applyCors(headers) {
  headers.set("Access-Control-Allow-Origin", "*");
  headers.set("Access-Control-Allow-Methods", "GET,HEAD,POST,PUT,PATCH,DELETE,OPTIONS");
  headers.set("Access-Control-Allow-Headers", "*");
}
